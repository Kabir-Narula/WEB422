import useSWR from 'swr';
import { Card, Button } from 'react-bootstrap';
import Link from 'next/link';
import Error from 'next/error';

const fetcher = (url) => fetch(url).then((res) => res.ok ? res.json() : Promise.reject(res));

const ArtworkCard = ({ objectID }) => {
  const { data, error } = useSWR(
    objectID ? `https://collectionapi.metmuseum.org/public/collection/v1/objects/${objectID}` : null, 
    fetcher
  );

  if (error) return <Error statusCode={error.status || 500} title={error.statusText || "An error occurred while fetching the data."} />;
  if (!data) return <div>Loading...</div>; // Or a custom loading component

  return (
    <Card style={{ width: '18rem', margin: '1rem', boxShadow: '0 4px 8px rgba(0,0,0,0.1)' }}>
      <Card.Img variant="top" src={data.primaryImageSmall || 'https://via.placeholder.com/375x375.png?text=Image+Not+Available'} style={{ height: '18rem', objectFit: 'cover' }} />
      <Card.Body>
        <Card.Title>{data.title || 'Information Not Available'}</Card.Title>
        <Card.Text>
          Date: {data.objectDate || 'N/A'}<br />
          Classification: {data.classification || 'N/A'}<br />
          Medium: {data.medium || 'N/A'}
        </Card.Text>
        <Link href={`/artwork/${objectID}`} passHref>
          <Button variant="primary">ID: {objectID}</Button>
        </Link>
      </Card.Body>
    </Card>
  );
};

export default ArtworkCard;
