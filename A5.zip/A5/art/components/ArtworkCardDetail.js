import useSWR from 'swr';
import { Card, Button } from 'react-bootstrap';
import Error from 'next/error';
import { useAtom } from 'jotai';
import { favouritesAtom } from '../store'; // Adjust path as necessary

const fetcher = (url) => fetch(url).then((res) => res.json());

const ArtworkCardDetail = ({ objectID }) => {
  const { data, error } = useSWR(
    `https://collectionapi.metmuseum.org/public/collection/v1/objects/${objectID}`,
    fetcher
  );
  const [favourites, setFavourites] = useAtom(favouritesAtom);
  const isFavourite = favourites.includes(objectID);

  const toggleFavourite = () => {
    setFavourites(current => {
      const updatedFavourites = current.includes(objectID)
        ? current.filter(id => id !== objectID)
        : [...current, objectID];
      localStorage.setItem('favourites', JSON.stringify(updatedFavourites));
      return updatedFavourites;
    });
  };

  if (error) return <Error statusCode={404} />;
  if (!data) return null; // Or a loading indicator

  return (
    <Card>
      {data.primaryImage && <Card.Img variant="top" src={data.primaryImage} />}
      <Card.Body>
        <Card.Title>{data.title || 'N/A'}</Card.Title>
        <Card.Text>
          Date: {data.objectDate || 'N/A'}<br />
          Classification: {data.classification || 'N/A'}<br />
          Medium: {data.medium || 'N/A'}<br /><br />
          Artist: {data.artistDisplayName || 'N/A'}<br />
          Credit Line: {data.creditLine || 'N/A'}<br />
          Dimensions: {data.dimensions || 'N/A'}<br />
          {data.artistWikidata_URL && (
            <a href={data.artistWikidata_URL} target="_blank" rel="noreferrer">Artist Wiki</a>
          )}
        </Card.Text>
        <Button variant={isFavourite ? "secondary" : "primary"} onClick={toggleFavourite}>
          {isFavourite ? 'Remove from Favourites' : 'Add to Favourites'}
        </Button>
      </Card.Body>
    </Card>
  );
};

export default ArtworkCardDetail;
