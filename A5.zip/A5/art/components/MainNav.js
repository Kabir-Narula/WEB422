import { Navbar, Nav, Form, FormControl, Button, NavDropdown } from 'react-bootstrap';
import { useRouter } from 'next/router';
import { useState } from 'react';

const MainNav = () => {
    const router = useRouter();
    const [expanded, setExpanded] = useState(false);

    const handleSearch = (e) => {
        e.preventDefault();
        const searchTerm = e.target.elements.search.value;
        router.push(`/artwork?title=true&q=${searchTerm}`);
        setExpanded(false);
    };

    const handleFavoritesClick = () => {
        router.push("/favourites");
        setExpanded(false);
    };

    const handleHistoryClick = () => {
        router.push("/history"); // Navigate to the "/history" page
        setExpanded(false);
    };

    return (
        <Navbar bg="rgba(0, 0, 0, 0.3)" variant="dark" fixed="top" expand="lg" className="navbar">
            <Navbar.Brand onClick={() => setExpanded(false)} className="brand">Kabir's Gallery</Navbar.Brand>
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-between">
                <Nav className="mr-auto">
                    <Nav.Link href="/" className="nav-link" active={router.pathname === "/"}>Home</Nav.Link>
                    <Nav.Link href="/search" className="nav-link" active={router.pathname === "/search"}>Advanced Search</Nav.Link>
                </Nav>
                <Nav>
                    <NavDropdown title="Current-User" id="collapsible-nav-dropdown" className="nav-link">
                        <NavDropdown.Item onClick={handleFavoritesClick} className="dropdown-item" active={router.pathname === "/favourites"}>Favourites</NavDropdown.Item>
                        <NavDropdown.Item onClick={handleHistoryClick} className="dropdown-item" active={router.pathname === "/history"}>Search History</NavDropdown.Item>
                    </NavDropdown>
                    <Form onSubmit={handleSearch} className="form-inline">
                        <FormControl type="text" placeholder="Search Artworks" className="form-control mr-sm-2" name="search" />
                        <Button type="submit" variant="outline-light" className="btn btn-outline-light">Search</Button>
                    </Form>
                </Nav>
            </Navbar.Collapse>
        </Navbar>
    );
};

export default MainNav;
