// Import necessary libraries and components
import { Col, Form, Row, Button } from "react-bootstrap";
import { useRouter } from "next/router";
import { useForm } from "react-hook-form";
import { useAtom } from 'jotai';
import { searchHistoryAtom } from '../store'; 
import styles from '@/styles/History.module.css';
 // Ensure this path correctly points to your store.js file

export default function AdvancedSearch() {
    const router = useRouter();  // Using the Next.js router
    const { register, handleSubmit, formState: { errors } } = useForm({
        defaultValues: {
            searchBy: 'title', 
            geoLocation: "", 
            medium: "", 
            isOnView: false, 
            isHighLight: false,
            q: "",
        },
    });

    // Utilize Jotai's useAtom hook for search history
    const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);

    // Function to handle form submission
    function submitForm(data) {
        let queryString = `${data.searchBy}=true`;

        if (data.geoLocation) {
            queryString += `&geoLocation=${data.geoLocation}`;
        }

        if (data.medium) {
            queryString += `&medium=${data.medium}`;
        }

        queryString += `&isOnView=${data.isOnView}`;
        queryString += `&isHighLight=${data.isHighLight}`;
        queryString += `&q=${data.q}`;

        // Update the search history atom
        setSearchHistory(prevHistory => [...prevHistory, queryString]);

        // Navigate to the artwork search results page
        router.push(`/artwork?${queryString}`);
    }

    // Render the advanced search form
    return (
        <>
            <Form onSubmit={handleSubmit(submitForm)}>
                <Row>
                    <Col>
                        <Form.Group className="mb-3">
                            <Form.Label>Search Query</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Enter search term" 
                                {...register("q", { required: true })} 
                                className={errors.q ? 'is-invalid' : ''}
                            />
                            {errors.q && <div className="invalid-feedback">This field is required.</div>}
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col md={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>Search By</Form.Label>
                            <Form.Select {...register("searchBy")} className={errors.searchBy ? 'is-invalid' : ''}>
                                <option value="title">Title</option>
                                <option value="tags">Tags</option>
                                <option value="artistOrCulture">Artist or Culture</option>
                            </Form.Select>
                        </Form.Group>
                    </Col>
                    <Col md={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>Geo Location</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Enter location" 
                                {...register("geoLocation")} 
                            />
                        </Form.Group>
                    </Col>
                    <Col md={4}>
                        <Form.Group className="mb-3">
                            <Form.Label>Medium</Form.Label>
                            <Form.Control 
                                type="text" 
                                placeholder="Enter medium" 
                                {...register("medium")} 
                            />
                        </Form.Group>
                    </Col>
                </Row>
                <Row>
                    <Col>
                        <Form.Check 
                            type="checkbox" 
                            label="Highlighted" 
                            {...register("isHighLight")}
                        />
                        <Form.Check 
                            type="checkbox" 
                            label="Currently on View" 
                            {...register("isOnView")}
                        />
                    </Col>
                </Row>
                <Row>
                    <Col><br />
                        <Button variant="primary" type="submit">
                            Submit
                        </Button>
                    </Col>
                </Row>
            </Form> 
        </>
    );
}
