// components/MainNav.js
import { Navbar, Nav, Form, FormControl, Button } from 'react-bootstrap';
import Link from 'next/link';
import { useRouter } from 'next/router';


const MainNav = () => {
  const router = useRouter();
  const handleSearch = (e) => {
    e.preventDefault();
    const searchTerm = e.target.elements.search.value; // Assuming 'search' is the name of your input field
    router.push(`/artwork?title=true&q=${searchTerm}`);
  };

  return (
    
    <Navbar bg="primary" variant="dark" fixed="top" className="navbar-dark">
      <Navbar.Brand>Kabir</Navbar.Brand>
      <Nav className="mr-auto">
        <Link href="/" passHref legacyBehavior><Nav.Link>Home</Nav.Link></Link>
        <Link href="/search" passHref legacyBehavior><Nav.Link>Advanced Search</Nav.Link></Link>
      </Nav>
      <Form inline className="d-flex" onSubmit={handleSearch}>
        <FormControl type="text" placeholder="Search" className="mr-sm-2" name="search" />
        <Button type="submit" variant="outline-light">Search</Button>
      </Form>
    </Navbar>
  );
};

export default MainNav;
