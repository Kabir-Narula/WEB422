/*********************************************************************************
* BTI425 – Assignment 4
*
* I declare that this assignment is my own work in accordance with Seneca's
* Academic Integrity Policy:
* 
* https://www.senecapolytechnic.ca/about/policies/academic-integrity-policy.html
* 
* Name: Kabir Narula Student ID: 127962223 Date: 8 March 2024
*
********************************************************************************/

import { Container, Row, Col, Image, Card } from 'react-bootstrap';

export default function Home() {
  return (
    <Container>
      <Row className="my-5">
        <Col>
          <Image src="https://upload.wikimedia.org/wikipedia/commons/3/30/Metropolitan_Museum_of_Art_%28The_Met%29_-_Central_Park%2C_NYC.jpg" alt="The Metropolitan Museum of Art" fluid rounded />
        </Col>
      </Row>
      <Row>
        <Col md={6} className="mb-4"> {/* Added mb-4 for spacing between the cards when on smaller screens */}
          <Card className="h-100"> {/* Added h-100 for equal height cards */}
            <Card.Body>
              <Card.Title>About the Met</Card.Title> {/* Added Card.Title for context */}
              <Card.Text>
                The Metropolitan Museum of Art of New York City, colloquially "the Met," is the largest art museum in the Americas...
              </Card.Text>
            </Card.Body>
          </Card>
        </Col>
        <Col md={6}>
          <Card className="h-100"> {/* Added h-100 for equal height cards */}
            <Card.Body>
              <Card.Title>History and Building</Card.Title> {/* Added Card.Title for context */}
              <Card.Text>
                The Fifth Avenue building opened on March 30, 1880. In 2021, despite the COVID-19 pandemic in New York City...
              </Card.Text>
              <Card.Link href="https://en.wikipedia.org/wiki/Metropolitan_Museum_of_Art" target="_blank" rel="noreferrer">Learn more...</Card.Link>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}
