let page = 1;
const perPage = 10;
let searchName = null;

document.addEventListener("DOMContentLoaded", () => {
  loadListingsData();
  addEventListeners();
});

async function fetchApi(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP error: ${response.status}`);
    return await response.json();
  } catch (error) {
    console.error("Fetch error:", error);
    throw error; // Rethrow for caller to handle
  }
}

async function loadListingsData() {
  let url = `https://gold-gifted-katydid.cyclic.app/api/listings?page=${page}&perPage=${perPage}`;
  if (searchName) url += `&name=${encodeURIComponent(searchName)}`;

  try {
    const data = await fetchApi(url);
    if (data.length > 0) {
      updateTable(data);
      updateCurrentPageNumber();
    } else {
      handleNoDataOrError("No data available");
    }
  } catch (error) {
    handleNoDataOrError("Error fetching data");
  }
}

function updateTable(data) {
  const tableBody = document
    .getElementById("listingsTable")
    .getElementsByTagName("tbody")[0];
  tableBody.innerHTML = data
    .map(
      (listing) => `
        <tr onclick="fetchAndShowDetails('${listing._id}')">
            <td>${listing.name}</td>
            <td>${listing.room_type}</td>
            <td>${listing.address.street}</td>
            <td>${listing.summary}<br>
            <strong>Accomodates: </strong>${listing.accommodates}<br>
                            <strong>Rating: </strong>${listing.review_scores.review_scores_rating} (${listing.number_of_reviews} Reviews)</td>
        </tr>
    `
    )
    .join("");
}

async function fetchAndShowDetails(listingId) {
  try {
    const listing = await fetchApi(
      `https://gold-gifted-katydid.cyclic.app/api/listings/${listingId}`
    );
    updateModalContent(listing);
  } catch (error) {
    console.error("Error fetching details:", error);
  }
}

function updateModalContent(listing) {
  const modalBody = document.querySelector("#detailsModal .modal-body");
  modalBody.innerHTML = `
        <img id="photo" onerror="this.onerror=null;this.src='https://placehold.co/600x400?text=Photo+Not+Available'"
             class="img-fluid w-100" src="${
               listing.images.picture_url
             }" alt="Listing Image">
        <p><strong>Location:</strong> ${listing.address.street}</p>
        <p><strong>Summary:</strong> ${listing.summary}</p>
        <p><strong>Price:</strong> $${listing.price?.toFixed(2)}</p>
        <p><strong>Room Type:</strong> ${listing.room_type}</p>
        <p><strong>Bed Type:</strong> ${listing.bed_type}</p>
        <p><strong>Number of Beds:</strong> ${listing.beds}</p>
    `;
  $("#detailsModal").modal("show");
}

function handleNoDataOrError(message) {
  document
    .getElementById("listingsTable")
    .getElementsByTagName(
      "tbody"
    )[0].innerHTML = `<tr><td colspan="4">${message}</td></tr>`;
}

function updateCurrentPageNumber() {
  document.getElementById("current-page").textContent = page;
}

function addEventListeners() {
  document.getElementById("previous-page").addEventListener("click", () => {
    if (page > 1) {
      --page;
      loadListingsData();
    }
  });

  document.getElementById("next-page").addEventListener("click", () => {
    ++page;
    loadListingsData();
  });

  document.getElementById("searchForm").addEventListener("submit", (event) => {
    event.preventDefault();
    searchName = document.getElementById("name").value;
    page = 1;
    loadListingsData();
  });

  document.getElementById("clearForm").addEventListener("click", () => {
    document.getElementById("name").value = "";
    searchName = null;
    page = 1;
    loadListingsData();
  });
}
