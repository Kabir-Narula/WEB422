import { useState, useEffect } from "react";
import Link from "next/link";
import Card from "react-bootstrap/Card";
import Spinner from "react-bootstrap/Spinner"; // Import Bootstrap Spinner for loading state
import ListingDetails from "@/components/ListingDetail";
import PageHeader from "@/components/PageHeader";

export async function getStaticProps() {
  try {
    const res = await fetch("https://gold-gifted-katydid.cyclic.app/api/listings/18173787");
    if (!res.ok) {
      throw new Error('Failed to fetch');
    }
    const data = await res.json();
    return { props: { listing: data } };
  } catch (error) {
    console.error("Failed to fetch listing data:", error);
    return { props: { listing: null, error: true } }; // Return an error prop if fetching fails
  }
}

export default function About({ listing, error }) {
  // State to manage loading state
  const [isLoading, setIsLoading] = useState(true);

  // Mimic fetching/loading data
  useEffect(() => {
    if (listing || error) {
      setIsLoading(false);
    }
  }, [listing, error]);

  if (isLoading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Spinner animation="border" role="status">
          <span className="visually-hidden">Loading...</span>
        </Spinner>
      </div>
    );
  }

  if (error) {
    return <p>Error loading the page. Please try again later.</p>;
  }

  return (
    <>
      <PageHeader text="About the Developer - Osamu Dazai" />
      <Card>
        <Card.Body>
          <p>
            Living in Yokohama, Japan, Osamu Dazai is a man of complexity and paradox. As a former executive of the Port Mafia and a current member of the Armed Detective Agency, he navigates his existence between light and shadows. His unique ability, "No Longer Human," allows him to nullify others' supernatural powers, making him a formidable ally and a dreaded enemy.
            <br /><br />
            Dazai's fascination with death, particularly his desire for a double suicide with a beautiful woman, underscores his morose and enigmatic persona. Despite his dark humor and seemingly cavalier attitude towards life, Dazai is deeply loyal to his colleagues, often putting their welfare above his own. His past haunts him, shaping his actions and relationships within the tangled web of Yokohama's underworld.
            <br /><br />
            This dichotomy of Dazai's character—his quest for death juxtaposed with his fierce loyalty and moments of profound insight—makes him a compelling figure in the narrative of "Bungo Stray Dogs."
          </p>
          <p style={{color: 'black'}}>
            <Link style={{color: 'black', textDecoration: 'underline', fontWeight: 'bold'}} href={`/listing/18173787`}>Click Here to Explore More</Link>
          </p>
        </Card.Body>
        <ListingDetails listing={listing} />
      </Card>
    </>
  );
}
