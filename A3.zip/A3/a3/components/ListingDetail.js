import { Container, Row, Col } from "react-bootstrap";

export default function ListingDetails(prop) {
  return (
    <>
      <Container>
        <Row>
          <Col lg>
            <img
              onError={(event) => {
                event.target.onError = null; // Remove the event handler to prevent infinite loop
                event.target.src =
                  "https://placehold.co/600x400?text=Photo+Not+Available";
              }}
              className="img-fluid w-100"
              src={prop.listing.images.picture_url}
              alt="listing image"
            />

            <br />
            <br />
          </Col>
          <Col lg>
            {prop.listing.neighborhood_overview}
            <br />
            <br />
            <strong>Price: </strong>${prop.listing.price.toFixed(2)}
            <br />
            <strong>Room: </strong>
            {prop.listing.room_type}
            <br />
            <strong>Real Bed: </strong>
            {prop.listing.bed_type} <br />
            <strong>Beds: </strong>
            {prop.listing.beds} <br />
            <strong>Reviews: </strong>
            {prop.listing.review_scores.review_scores_rating}
            <br />
            <strong>Number of Reviews: </strong>$
            {prop.listing.number_of_reviews}
            <br />
          </Col>
        </Row>
      </Container>
    </>
  );
}
